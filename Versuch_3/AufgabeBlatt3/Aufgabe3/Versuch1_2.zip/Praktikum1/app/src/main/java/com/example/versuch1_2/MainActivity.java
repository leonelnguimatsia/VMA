package com.example.versuch1_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button nextActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nextActivity = findViewById(R.id.btn_nextactivity);
        nextActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.v("DEMO","---> ActivityMain: Click on Button <--- ");
                Intent myIntent = new Intent(view.getContext(), MainActivity2.class); // Durch Übergabe dieses Intent-Objekts an startActivity():
                //myIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                // Log.v("DEMO","Activity1: Intent.getComponent() = "+myIntent.getComponent());
                view.getContext().startActivity(myIntent);
            }
        });
    }
}