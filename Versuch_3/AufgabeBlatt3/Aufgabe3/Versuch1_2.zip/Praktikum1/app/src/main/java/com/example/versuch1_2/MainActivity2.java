package com.example.versuch1_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity {

    Button zurück;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        zurück = findViewById(R.id.btn_back);
        zurück.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.v("DEMO","---> Back Button: Click on Button <--- ");
                Intent myIntent = new Intent(view.getContext(), MainActivity.class); // Durch Übergabe dieses Intent-Objekts an startActivity():
                //myIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                // Log.v("DEMO","Activity1: Intent.getComponent() = "+myIntent.getComponent());
                view.getContext().startActivity(myIntent);
            }
        });
    }
}